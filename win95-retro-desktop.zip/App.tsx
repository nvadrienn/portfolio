
import React, { useState, useCallback } from 'react';
import Window from './components/Window';
import Taskbar from './components/Taskbar';
import DesktopIcon from './components/DesktopIcon';
import { WindowData, DesktopAppId } from './types';

const App: React.FC = () => {
  const [windows, setWindows] = useState<Record<DesktopAppId, WindowData>>({
    'my-computer': {
      id: 'my-computer',
      title: 'My Computer',
      isOpen: true,
      isMinimized: false,
      zIndex: 10,
      position: { x: 50, y: 50 },
      icon: '💻',
      content: <MyComputerContent />
    },
    'about': {
      id: 'about',
      title: 'About Me.txt - Notepad',
      isOpen: false,
      isMinimized: false,
      zIndex: 1,
      position: { x: 100, y: 100 },
      icon: '📄',
      content: <AboutContent />
    },
    'projects': {
      id: 'projects',
      title: 'My Projects',
      isOpen: false,
      isMinimized: false,
      zIndex: 1,
      position: { x: 150, y: 80 },
      icon: '📂',
      content: <ProjectsContent />
    },
    'contact': {
      id: 'contact',
      title: 'Contact Me',
      isOpen: false,
      isMinimized: false,
      zIndex: 1,
      position: { x: 200, y: 120 },
      icon: '📧',
      content: <ContactContent />
    },
    'trash': {
      id: 'trash',
      title: 'Recycle Bin',
      isOpen: false,
      isMinimized: false,
      zIndex: 1,
      position: { x: 300, y: 200 },
      icon: '🗑️',
      content: <div className="p-4 text-center">Your trash is empty. Just like my social life in 1998.</div>
    }
  });

  const [topZ, setTopZ] = useState(20);

  const bringToFront = useCallback((id: DesktopAppId) => {
    setTopZ(prev => prev + 1);
    setWindows(prev => ({
      ...prev,
      [id]: { ...prev[id], zIndex: topZ + 1, isMinimized: false, isOpen: true }
    }));
  }, [topZ]);

  const toggleMinimize = useCallback((id: DesktopAppId) => {
    setWindows(prev => ({
      ...prev,
      [id]: { ...prev[id], isMinimized: !prev[id].isMinimized }
    }));
    if (windows[id].isMinimized) bringToFront(id);
  }, [bringToFront, windows]);

  const closeWindow = useCallback((id: DesktopAppId) => {
    setWindows(prev => ({
      ...prev,
      [id]: { ...prev[id], isOpen: false }
    }));
  }, []);

  const openWindow = useCallback((id: DesktopAppId) => {
    setWindows(prev => ({
      ...prev,
      [id]: { ...prev[id], isOpen: true, isMinimized: false }
    }));
    bringToFront(id);
  }, [bringToFront]);

  const updatePosition = useCallback((id: DesktopAppId, x: number, y: number) => {
    setWindows(prev => ({
      ...prev,
      [id]: { ...prev[id], position: { x, y } }
    }));
  }, []);

  return (
    <div 
      className="relative w-screen h-screen overflow-hidden select-none bg-no-repeat bg-cover bg-center"
      style={{ 
        backgroundImage: 'url("https://upload.wikimedia.org/wikipedia/commons/2/21/Bliss_%28Windows_XP_wallpaper%29.jpg")',
        backgroundColor: '#008080' // Fallback teal
      }}
    >
      {/* Desktop Icons */}
      <div className="p-4 flex flex-col gap-6 w-max">
        <DesktopIcon icon="💻" label="My Computer" onDoubleClick={() => openWindow('my-computer')} />
        <DesktopIcon icon="📄" label="About Me" onDoubleClick={() => openWindow('about')} />
        <DesktopIcon icon="📂" label="Projects" onDoubleClick={() => openWindow('projects')} />
        <DesktopIcon icon="📧" label="Contact" onDoubleClick={() => openWindow('contact')} />
        <DesktopIcon icon="🗑️" label="Recycle Bin" onDoubleClick={() => openWindow('trash')} />
      </div>

      {/* Render Windows */}
      {(Object.values(windows) as WindowData[]).map((win) => (
        win.isOpen && !win.isMinimized && (
          <Window
            key={win.id}
            data={win}
            onClose={() => closeWindow(win.id as DesktopAppId)}
            onMinimize={() => toggleMinimize(win.id as DesktopAppId)}
            onFocus={() => bringToFront(win.id as DesktopAppId)}
            onMove={(x, y) => updatePosition(win.id as DesktopAppId, x, y)}
          />
        )
      ))}

      {/* Taskbar */}
      <Taskbar 
        windows={Object.values(windows) as WindowData[]} 
        onAppClick={(id) => {
          if (windows[id as DesktopAppId].isMinimized || !windows[id as DesktopAppId].isOpen) {
             openWindow(id as DesktopAppId);
          } else {
             toggleMinimize(id as DesktopAppId);
          }
        }}
      />
    </div>
  );
};

// Content Components
const MyComputerContent: React.FC = () => (
  <div className="p-2 grid grid-cols-4 gap-4 bg-white min-h-[200px] win95-bevel-inset">
    {[
      { icon: '💾', label: '3½ Floppy (A:)' },
      { icon: '💽', label: 'Hard Drive (C:)' },
      { icon: '💿', label: 'Audio CD (D:)' },
      { icon: '🔌', label: 'Control Panel' },
    ].map((item, i) => (
      <div key={i} className="flex flex-col items-center gap-1 cursor-pointer hover:bg-blue-100 p-2">
        <span className="text-3xl">{item.icon}</span>
        <span className="text-[11px] text-center">{item.label}</span>
      </div>
    ))}
  </div>
);

const AboutContent: React.FC = () => (
  <div className="bg-white win95-bevel-inset p-4 min-h-[300px] overflow-y-auto text-black font-mono leading-tight">
    <p className="mb-4">HELLO WORLD!</p>
    <p className="mb-2">I am a Senior Frontend Engineer who loves the 90s aesthetic.</p>
    <p className="mb-2">Expertise in:</p>
    <ul className="list-disc ml-6 mb-4">
      <li>React & TypeScript</li>
      <li>Tailwind CSS</li>
      <li>Gemini API Integrations</li>
      <li>Retro UI Design</li>
    </ul>
    <p>Feel free to look around this desktop. It's built with modern tech but styled with nostalgia.</p>
  </div>
);

const ProjectsContent: React.FC = () => (
  <div className="p-4 bg-white win95-bevel-inset flex flex-col gap-4">
    <div className="flex gap-4 items-start p-2 border-b border-gray-200">
      <span className="text-4xl">🎮</span>
      <div>
        <h3 className="font-bold underline">Space Invaders 95</h3>
        <p className="text-sm">Classic arcade remake using Canvas API.</p>
      </div>
    </div>
    <div className="flex gap-4 items-start p-2 border-b border-gray-200">
      <span className="text-4xl">📼</span>
      <div>
        <h3 className="font-bold underline">VHS Filter Tool</h3>
        <p className="text-sm">Real-time video processing with WebGL.</p>
      </div>
    </div>
    <div className="flex gap-4 items-start p-2 border-b border-gray-200">
      <span className="text-4xl">📟</span>
      <div>
        <h3 className="font-bold underline">BeeperJS</h3>
        <p className="text-sm">A notification library that sounds like a pager.</p>
      </div>
    </div>
  </div>
);

const ContactContent: React.FC = () => (
  <div className="p-6 bg-[#c0c0c0] flex flex-col gap-4">
    <div className="flex flex-col gap-1">
      <label className="text-sm">To:</label>
      <div className="bg-white p-1 win95-bevel-inset text-sm">webmaster@retro.com</div>
    </div>
    <div className="flex flex-col gap-1">
      <label className="text-sm">Message:</label>
      <textarea className="bg-white p-2 win95-bevel-inset h-32 text-sm resize-none focus:outline-none" defaultValue="Enter your message here..."></textarea>
    </div>
    <button className="win95-bevel win95-button bg-[#c0c0c0] px-4 py-1 self-end active:bg-[#d0d0d0]">
      Send Mail
    </button>
  </div>
);

export default App;
