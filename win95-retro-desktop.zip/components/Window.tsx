
import React, { useState, useEffect, useRef } from 'react';
import { WindowData } from '../types';

interface WindowProps {
  data: WindowData;
  onClose: () => void;
  onMinimize: () => void;
  onFocus: () => void;
  onMove: (x: number, y: number) => void;
}

const Window: React.FC<WindowProps> = ({ data, onClose, onMinimize, onFocus, onMove }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const windowRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    onFocus();
    if (e.button !== 0) return;
    setIsDragging(true);
    setOffset({
      x: e.clientX - data.position.x,
      y: e.clientY - data.position.y
    });
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      onMove(e.clientX - offset.x, e.clientY - offset.y);
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, offset, onMove]);

  return (
    <div
      ref={windowRef}
      className="absolute win95-bevel bg-[#c0c0c0] flex flex-col min-w-[300px] shadow-lg"
      style={{
        left: data.position.x,
        top: data.position.y,
        zIndex: data.zIndex,
      }}
      onClick={onFocus}
    >
      {/* Title Bar */}
      <div
        className={`flex items-center justify-between p-1 cursor-default select-none ${isDragging ? 'win95-title-bar' : 'win95-title-bar'}`}
        onMouseDown={handleMouseDown}
      >
        <div className="flex items-center gap-1 overflow-hidden">
          <span className="text-sm px-1 text-white truncate font-bold drop-shadow-[1px_1px_0_rgba(0,0,0,0.5)]">
            {data.title}
          </span>
        </div>
        
        <div className="flex gap-[2px]">
          <button 
            className="win95-bevel win95-button w-4 h-4 bg-[#c0c0c0] flex items-center justify-center text-[10px] font-bold"
            onClick={(e) => { e.stopPropagation(); onMinimize(); }}
          >
            _
          </button>
          <button 
            className="win95-bevel win95-button w-4 h-4 bg-[#c0c0c0] flex items-center justify-center text-[10px] font-bold"
            disabled
          >
            □
          </button>
          <button 
            className="win95-bevel win95-button w-4 h-4 bg-[#c0c0c0] flex items-center justify-center text-[12px] font-bold ml-1"
            onClick={(e) => { e.stopPropagation(); onClose(); }}
          >
            ✕
          </button>
        </div>
      </div>

      {/* Menu Bar (Fake) */}
      <div className="flex gap-4 px-2 py-1 text-[11px] border-b border-gray-400">
        <span className="cursor-pointer hover:bg-blue-800 hover:text-white px-1"><u>F</u>ile</span>
        <span className="cursor-pointer hover:bg-blue-800 hover:text-white px-1"><u>E</u>dit</span>
        <span className="cursor-pointer hover:bg-blue-800 hover:text-white px-1"><u>V</u>iew</span>
        <span className="cursor-pointer hover:bg-blue-800 hover:text-white px-1"><u>H</u>elp</span>
      </div>

      {/* Content */}
      <div className="relative flex-1 p-1 overflow-hidden">
        {data.content}
      </div>
    </div>
  );
};

export default Window;
