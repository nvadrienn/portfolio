
// Add React import to support React types
import React from 'react';

export interface WindowData {
  id: string;
  title: string;
  isOpen: boolean;
  isMinimized: boolean;
  zIndex: number;
  position: { x: number; y: number };
  icon: string;
  content: React.ReactNode;
}

export type DesktopAppId = 'my-computer' | 'about' | 'projects' | 'contact' | 'trash';
